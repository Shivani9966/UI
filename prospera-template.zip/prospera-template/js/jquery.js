$(document).ready(function() {
    $("#card2").click(function() {
        $("#card1").toggle();
        $("#card1").css("width", "200");
        $("#card1").css("height", "300");

    });
    $("#downdropBtn").click(function() {
        $("#carouselExampleControls").toggle();
    });
   
});
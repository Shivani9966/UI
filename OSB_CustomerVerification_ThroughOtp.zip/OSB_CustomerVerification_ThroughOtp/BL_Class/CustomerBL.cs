﻿using OSB.DL;
using OSB.Entity.BusinessEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSB.BL
{
    public class CustomerBL
    {
        CustomerDL obj = new CustomerDL();
        public bool VerifyEmail(string email)
        {
            
            var isValid = obj.VerifyEmail(email);

            return isValid;

        }

        public void SendOtpBL(string email)
        {
            obj.SendOtpDL(email);
            

        }

        public int VerifyOtpBL(OTP_VM otpNumber)
        {
            int IsValidOtp = obj.VerifyOtpDL(otpNumber);
            return IsValidOtp;
        }
    }
}

﻿using OSB.Entity.DataEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using OSB.Entity.BusinessEntity;

namespace OSB.DL
{
    public class CustomerDL
    {
        OSBDBEntities context = new OSBDBEntities();

        public bool VerifyEmail(string email)
        {
            var useremail = context.Customers.Any(t => t.EmailId == email);
            if (useremail != false)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void SendOtpDL(string email)
        {

            int CustomerId = context.Customers.Where(x => x.EmailId == email).Select(x => x.CustomerId).FirstOrDefault();
            
           // Session["CustomerId"] = CustomerId;
            var Otp = GenerateOTP();
            var o = new Otp();

            o.OtpNumber = Otp;
            o.CreationTime = System.DateTime.Now;
             o.ExpiryTime = System.DateTime.Now.AddMinutes(5);
            //o.ExpiryTime = System.DateTime.Now.AddSeconds(60);
            o.CustomerId = CustomerId;

            context.Otps.Add(o);
            context.SaveChanges();

            SendOTPEmail(email,Otp);
         
        }

        public int GenerateOTP()
        {
            string OTPLength = "4";
            string OTP = string.Empty;

            string Chars = string.Empty;
            Chars = "1,2,3,4,5,6,7,8,9,0";

            char[] seplitChar = { ',' };
            string[] arr = Chars.Split(seplitChar);
            string NewOTP = "";
            string temp = "";
            Random rand = new Random();
            for (int i = 0; i < Convert.ToInt32(OTPLength); i++)
            {
                temp = arr[rand.Next(0, arr.Length)];
                NewOTP += temp;
                OTP = NewOTP;
            }
            return Int32.Parse(OTP);
        }

        public void SendOTPEmail(string emailId, int OTP)
        {

            var fromMail = new MailAddress("project.grpid23@gmail.com", "Disha"); // set your email  
            var fromEmailpassword = "Disha@123"; // Set your password   
            var toEmail = new MailAddress(emailId);

            var smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential(fromMail.Address, fromEmailpassword);

            var Message = new MailMessage(fromMail, toEmail);
            Message.Subject = "OTP For Online Car Service Booking";
            Message.Body ="<br/><br/>OTP for User Verification : " + OTP;
            Message.IsBodyHtml = true;
            smtp.Send(Message);
        }

        public int VerifyOtpDL(OTP_VM otp)
        {
            int IsValidOTP;
            int customerID = context.Customers.Where(t => t.EmailId == otp.EmailId).Select(x => x.CustomerId).FirstOrDefault();

            if (customerID > 0)
            { 
                int latestOTPinDB = context.Otps.Where(x => x.CustomerId == customerID).OrderByDescending(x => x.CreationTime).Select(x => x.OtpNumber).FirstOrDefault();
                DateTime expirytimeLatestOTP = context.Otps.Where(x => x.CustomerId == customerID).OrderByDescending(x => x.CreationTime).Select(x => x.ExpiryTime).FirstOrDefault();
                int value = DateTime.Compare(expirytimeLatestOTP, System.DateTime.Now);

                if (otp.OtpNumber == latestOTPinDB && value >= 0)
                {
                    // 0 = valid otp
                    IsValidOTP = 0;
                }
                else if (otp.OtpNumber == latestOTPinDB && value < 0)
                {
                    // 1 = valid otp but expire the time 
                    IsValidOTP = 1;
                }
                else
                {
                    // 2  = invalid otp
                    IsValidOTP = 2;
                }

            }
            else
            {
                // 3 = customer not exist;
                IsValidOTP = 3;
            }

            return IsValidOTP;
        }
    }
}

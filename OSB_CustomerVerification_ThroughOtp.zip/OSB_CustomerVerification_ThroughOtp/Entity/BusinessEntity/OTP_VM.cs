﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSB.Entity.BusinessEntity
{
   public class OTP_VM
    {
        public int OtpId { get; set; }
        public int OtpNumber { get; set; }
        public System.DateTime CreationTime { get; set; }
        public System.DateTime ExpiryTime { get; set; }
        public int CustomerId { get; set; }
        public string EmailId { get; set; }
    }
}

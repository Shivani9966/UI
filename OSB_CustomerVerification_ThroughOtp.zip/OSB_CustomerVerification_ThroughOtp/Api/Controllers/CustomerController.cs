﻿using OSB.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OSB.Entity.BusinessEntity;

namespace OSB.WebAPI.Controllers
{
    public class CustomerController : ApiController
    {
        CustomerBL obj = new CustomerBL();
        [HttpPost]
        [Route("api/Customer/SendOtp")]
        public IHttpActionResult SendOtp(OTP_VM user)
        {
                var isValid = obj.VerifyEmail(user.EmailId);
            if (isValid)
            { 
               obj.SendOtpBL(user.EmailId);
            }
            else
            {
                

            }
            return Ok();
        }

        [HttpPost]
        [Route("api/Customer/VerifyOtp")]
        public IHttpActionResult VerifyOtp(OTP_VM userotp)
        {
            int IsValidOtp = obj.VerifyOtpBL(userotp);
               switch (IsValidOtp)
            {
                case 0:
                    return Ok("Valid");
                    break;
                case 1:
                    return Ok("Expired");
                    break;
                case 2:
                    return Ok("InValid");
                    break;
                default:
                    return Ok("InValidEmail");
                    break;



            };
        }
    }
}
